package com.example.springmysqlcountrymarch26project.controller;

public class ResourceNotFoundException extends Exception {
    public ResourceNotFoundException(String s) {


    }
}
