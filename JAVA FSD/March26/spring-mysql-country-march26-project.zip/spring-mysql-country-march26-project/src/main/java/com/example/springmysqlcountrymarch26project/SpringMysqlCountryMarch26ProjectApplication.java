package com.example.springmysqlcountrymarch26project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMysqlCountryMarch26ProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringMysqlCountryMarch26ProjectApplication.class, args);
    }

}
