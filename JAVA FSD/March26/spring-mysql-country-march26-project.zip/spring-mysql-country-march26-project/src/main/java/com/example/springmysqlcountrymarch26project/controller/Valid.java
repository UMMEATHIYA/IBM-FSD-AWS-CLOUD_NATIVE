package com.example.springmysqlcountrymarch26project.controller;

public @interface Valid {
}
