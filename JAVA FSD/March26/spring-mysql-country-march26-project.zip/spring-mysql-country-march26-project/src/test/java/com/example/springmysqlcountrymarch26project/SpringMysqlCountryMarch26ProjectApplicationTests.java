package com.example.springmysqlcountrymarch26project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMysqlCountryMarch26ProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
