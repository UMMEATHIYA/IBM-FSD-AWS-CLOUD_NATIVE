package com.example.employeeeaddbuttonh2database.service;

import com.example.employeeeaddbuttonh2database.model.Employee;

import java.util.List;

public interface EmployeeService {

    public List<Employee> getAllEmployee();

    public Employee createEmployee(Employee employee);

}
