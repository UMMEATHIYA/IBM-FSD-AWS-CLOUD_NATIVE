package com.example.employeethymeleafdatabaseh2connection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeThymeleafDatabaseH2ConnectionApplicationTests {

    @Test
    void contextLoads() {
    }

}
