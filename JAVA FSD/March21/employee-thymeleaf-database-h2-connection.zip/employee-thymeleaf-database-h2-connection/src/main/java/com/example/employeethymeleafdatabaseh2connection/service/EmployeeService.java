package com.example.employeethymeleafdatabaseh2connection.service;

import com.example.employeethymeleafdatabaseh2connection.model.Employee;

import java.util.List;

public interface EmployeeService {

    public List<Employee> getAllEmployee();
    public Employee findById(int theId);
    public Employee deleteEmployeeById(int theId);
    public Employee createEmployee(Employee employee);
}
