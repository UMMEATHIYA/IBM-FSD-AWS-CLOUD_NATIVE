package com.example.employeethymeleafdatabaseh2connection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeThymeleafDatabaseH2ConnectionApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeThymeleafDatabaseH2ConnectionApplication.class, args);
    }

}
