package com.example.employeerelationshipmanagement.controller;

import com.example.employeerelationshipmanagement.model.Employee;
import com.example.employeerelationshipmanagement.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/employees")
public class Employeecontroller {
    private EmployeeService employeeService;

    @Autowired
    public Employeecontroller(EmployeeService employeeService) {
        super();
        this.employeeService = employeeService;
    }

    @GetMapping("/list")
    public String getEmployees(Model model, String keyword)
    {
        List<Employee> list=employeeService.getAllEmployee();
        if(keyword!=null){
            model.addAttribute("employees", employeeService.findByKeyword(keyword));
        }
        else {
            model.addAttribute("employees", list);
        }
        return "list-employees";
    }
    @GetMapping("/showFormForAdd")
    public String showFormForAdd(Model theModel) {
        // create model attribute to bind form data
        Employee theEmployee = new Employee();
        theModel.addAttribute("employee", theEmployee);
        return "employee-form";
    }
    @PostMapping("/save")
    public String saveEmployee(@ModelAttribute("employee") Employee theEmployee) {

        employeeService.createEmployee(theEmployee);
        return "redirect:/employees/list";
    }
    @GetMapping("/showFormForUpdate")
    public String showFormForUpdate(@RequestParam("employeeId") int theId,
                                    Model theModel) {

        Employee theEmployee = employeeService.findById(theId);

        theModel.addAttribute("employee", theEmployee);

        return "employee-form";
    }
    @RequestMapping("/delete")
    public String deleteEmployeeById(@RequestParam("employeeId") int theId){
        employeeService.deleteEmployeeById(theId);
        return "redirect:/employees/list";
    }


}
