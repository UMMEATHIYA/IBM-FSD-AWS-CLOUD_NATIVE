package comm;

public class MySubClass2 implements MyParent{
    @Override
    public String Message() {
        System.out.println("This is second message");
        return null;
    }

    @Override
    public void a() {

    }
}
