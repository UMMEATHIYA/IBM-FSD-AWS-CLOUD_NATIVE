package comm;

public abstract class Parent {
    public abstract String Message();


    public void display()
    {
        System.out.println("Hello All");
    }
}
