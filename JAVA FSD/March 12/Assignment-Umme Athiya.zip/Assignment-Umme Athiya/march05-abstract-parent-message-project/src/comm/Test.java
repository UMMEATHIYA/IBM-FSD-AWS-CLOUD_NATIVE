package comm;

public class Test {
    public static void main(String args[])
    {
        Parent sb1 = new SubClass1();
        sb1.Message();
        Parent sb2 = new SubClass2();
        sb2.Message();

    }
}
