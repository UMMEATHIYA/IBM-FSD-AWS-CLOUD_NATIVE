package comm;

public class MySubClass1 implements MyParent{
    @Override
    public String Message() {
        System.out.println("This is first message");
        return null;
    }

    @Override
    public void a() {

    }
}
