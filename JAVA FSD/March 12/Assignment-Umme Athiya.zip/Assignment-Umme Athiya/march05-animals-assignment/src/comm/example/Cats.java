package comm.example;

public class Cats extends Animals{
    @Override
    public void cats() {
        System.out.println("Cats meow");

    }

    @Override
    public void dogs() {

    }

    @Override
    public void display() {
        super.display();
        System.out.println("Cats:-");
    }
}
