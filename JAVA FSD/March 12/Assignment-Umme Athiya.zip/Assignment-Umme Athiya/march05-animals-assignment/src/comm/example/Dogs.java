package comm.example;

public class Dogs extends Animals{
    @Override
    public void cats() {

    }

    @Override
    public void dogs() {
        System.out.println("Dogs bark");

    }

    @Override
    public void display() {
        super.display();
        System.out.println("Dogs:- ");
    }
}
