package comm.example;

public class TestInt {
    public static void main(String[] args) {
        Animals c = new Cats();
        Animals d = new Dogs();
        c.display();
        c.cats();
        d.display();
        d.dogs();
    }
}
