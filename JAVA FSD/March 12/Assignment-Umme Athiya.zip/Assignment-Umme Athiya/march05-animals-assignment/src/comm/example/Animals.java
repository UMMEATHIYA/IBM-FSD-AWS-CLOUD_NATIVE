package comm.example;

public abstract class Animals {
    public abstract void cats();
    public abstract void dogs();

    public void display()
    {

        System.out.println("");
    }
}
