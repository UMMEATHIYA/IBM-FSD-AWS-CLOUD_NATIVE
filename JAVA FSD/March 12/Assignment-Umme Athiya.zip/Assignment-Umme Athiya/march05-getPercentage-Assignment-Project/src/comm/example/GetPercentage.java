package comm.example;

public abstract class GetPercentage {
    public abstract float getPercentage();


    public void display()
    {

        System.out.println("Displaying percentage of Student A and B");
    }
}
