package comm.example;

public class TestAbs {
    public static void main(String[] args) {
        GetPercentage gc1 = new ClassA();
        gc1.display();
        gc1.getPercentage();
        GetPercentage gc2 = new ClassB();
        gc2.getPercentage();
    }
}
