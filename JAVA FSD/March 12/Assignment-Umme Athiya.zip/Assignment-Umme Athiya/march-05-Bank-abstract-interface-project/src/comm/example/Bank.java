package comm.example;

public abstract class Bank {
    public abstract double getBalance();


    public void display()
    {
        System.out.println("This is first subclass");
    }
}
